import { useState } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Label } from '@/components/ui/label.jsx'
import { 
  Mail, 
  Phone, 
  MapPin, 
  MessageCircle,
  User,
  Award,
  GraduationCap,
  Wrench,
  Heart,
  Send,
  Menu,
  X
} from 'lucide-react'
import profileImage from './assets/profile.jpeg'
import './App.css'

function App() {
  const [activeSection, setActiveSection] = useState('hakkinda')
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [isChatbotOpen, setIsChatbotOpen] = useState(false)
  const [chatMessages, setChatMessages] = useState([
    { type: 'bot', message: 'Merhaba! Size nasıl yardımcı olabilirim?' }
  ])
  const [chatInput, setChatInput] = useState('')

  const menuItems = [
    { id: 'hakkinda', label: 'Hakkında', icon: User },
    { id: 'sertifikalar', label: 'Sertifikalar', icon: Award },
    { id: 'egitim', label: 'Eğitim', icon: GraduationCap },
    { id: 'yetenekler', label: 'Yetenekler', icon: Wrench },
    { id: 'ilgi-alanlari', label: 'İlgi Alanları', icon: Heart },
    { id: 'iletisim', label: 'İletişim', icon: Mail },
    { id: 'danismanlik', label: 'Danışmanlık', icon: MessageCircle }
  ]

  const scrollToSection = (sectionId) => {
    setActiveSection(sectionId)
    setIsMobileMenuOpen(false)
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
  }

  const handleChatSubmit = (e) => {
    e.preventDefault()
    if (!chatInput.trim()) return

    const userMessage = chatInput.trim()
    setChatMessages(prev => [...prev, { type: 'user', message: userMessage }])
    
    // Basit chatbot yanıtları
    let botResponse = ''
    const lowerInput = userMessage.toLowerCase()
    
    if (lowerInput.includes('danışmanlık')) {
      botResponse = "Danışmanlık almak için lütfen 'Danışmanlık' sekmesindeki formu doldurun, en kısa sürede sizinle iletişime geçelim. 😊"
    } else if (lowerInput.includes('iletişim')) {
      botResponse = "İletişim bilgilerim 'İletişim' bölümünde yer almaktadır. E-posta, telefon ve adres bilgilerime oradan ulaşabilirsiniz."
    } else if (lowerInput.includes('hakkında') || lowerInput.includes('hakkımda')) {
      botResponse = "Hakkımda daha fazla bilgi almak için 'Hakkında' bölümünü ziyaret edebilirsiniz."
    } else if (lowerInput.includes('sertifika')) {
      botResponse = "Sahip olduğum sertifikaları 'Sertifikalar' bölümünde görebilirsiniz."
    } else if (lowerInput.includes('eğitim')) {
      botResponse = "Eğitim geçmişim 'Eğitim' bölümünde detaylı olarak yer almaktadır."
    } else if (lowerInput.includes('yetenek') || lowerInput.includes('beceri')) {
      botResponse = "Teknik ve sosyal yeteneklerimi 'Yetenekler' bölümünde inceleyebilirsiniz."
    } else if (lowerInput.includes('ilgi') || lowerInput.includes('hobi')) {
      botResponse = "Hobiler ve ilgi alanlarım 'İlgi Alanları' bölümünde listelenmiştir."
    } else if (lowerInput.includes('portföy') || lowerInput.includes('portfolio') || lowerInput.includes('web site') || lowerInput.includes('website') || lowerInput.includes('site')) {
      botResponse = "Bu portföy web sitesi hakkında sorularınızı yanıtlayabilirim. Hangi bölüm hakkında bilgi almak istiyorsunuz?"
    } else {
      botResponse = "Üzgünüm, yardımcı olabileceğim başka bir durum var mı?"
    }

    setTimeout(() => {
      setChatMessages(prev => [...prev, { type: 'bot', message: botResponse }])
    }, 1000)
    
    setChatInput('')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-4 -left-4 w-72 h-72 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob"></div>
        <div className="absolute -top-4 -right-4 w-72 h-72 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-20 w-72 h-72 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-blob animation-delay-4000"></div>
      </div>

      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-md border-b border-gray-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <span className="text-xl font-bold text-gray-900">Portföy</span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {menuItems.map((item) => {
                  const Icon = item.icon
                  return (
                    <button
                      key={item.id}
                      onClick={() => scrollToSection(item.id)}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center gap-2 ${
                        activeSection === item.id
                          ? 'bg-blue-100 text-blue-700'
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                      }`}
                    >
                      <Icon size={16} />
                      {item.label}
                    </button>
                  )
                })}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100"
              >
                {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-gray-200">
              {menuItems.map((item) => {
                const Icon = item.icon
                return (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors duration-200 flex items-center gap-2 ${
                      activeSection === item.id
                        ? 'bg-blue-100 text-blue-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                    }`}
                  >
                    <Icon size={16} />
                    {item.label}
                  </button>
                )
              })}
            </div>
          </div>
        )}
      </nav>

      {/* Main Content */}
      <main className="pt-16 relative z-10">
        {/* Hakkında Section */}
        <section id="hakkinda" className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="mb-8">
              <img
                src={profileImage}
                alt="Profil Resmi"
                className="w-32 h-32 rounded-full mx-auto mb-6 shadow-lg object-cover"
              />
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Merhaba, Ben [İsim]</h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
                Teknoloji ve inovasyona tutkulu bir profesyonelim. Yaratıcı çözümler geliştirmeyi ve 
                sürekli öğrenmeyi seven biriyim. Projelerimde kalite ve detaya önem veririm.
              </p>
            </div>
          </div>
        </section>

        {/* Sertifikalar Section */}
        <section id="sertifikalar" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Sertifikalar</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  name: "React Developer Certification",
                  description: "Modern React uygulamaları geliştirme sertifikası",
                  date: "2024"
                },
                {
                  name: "AWS Cloud Practitioner",
                  description: "Amazon Web Services bulut teknolojileri sertifikası",
                  date: "2023"
                },
                {
                  name: "JavaScript Advanced",
                  description: "İleri seviye JavaScript programlama sertifikası",
                  date: "2023"
                }
              ].map((cert, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow duration-300 card-hover">
                  <CardHeader>
                    <CardTitle className="text-lg">{cert.name}</CardTitle>
                    <CardDescription>{cert.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Badge variant="secondary">{cert.date}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Eğitim Section */}
        <section id="egitim" className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Eğitim</h2>
            <div className="relative">
              <div className="absolute left-4 md:left-1/2 transform md:-translate-x-px top-0 bottom-0 w-0.5 bg-gray-300"></div>
              {[
                {
                  degree: "Bilgisayar Mühendisliği Yüksek Lisans",
                  school: "İstanbul Teknik Üniversitesi",
                  year: "2022-2024",
                  description: "Yazılım geliştirme ve sistem tasarımı alanında uzmanlaşma"
                },
                {
                  degree: "Bilgisayar Mühendisliği Lisans",
                  school: "Boğaziçi Üniversitesi",
                  year: "2018-2022",
                  description: "Temel bilgisayar bilimleri ve programlama eğitimi"
                }
              ].map((edu, index) => (
                <div key={index} className={`relative flex items-center mb-8 timeline-item ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'}`}>
                  <div className="flex-1 md:w-1/2">
                    <Card className="ml-8 md:ml-0 md:mr-8 card-hover">
                      <CardHeader>
                        <CardTitle className="text-lg">{edu.degree}</CardTitle>
                        <CardDescription>{edu.school}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Badge variant="outline" className="mb-2">{edu.year}</Badge>
                        <p className="text-sm text-gray-600">{edu.description}</p>
                      </CardContent>
                    </Card>
                  </div>
                  <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 w-3 h-3 bg-blue-500 rounded-full border-2 border-white animate-pulse-glow"></div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Yetenekler Section */}
        <section id="yetenekler" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Yetenekler</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-6">Teknik Yetenekler</h3>
                {[
                  { name: "React & JavaScript", level: 90 },
                  { name: "Python", level: 85 },
                  { name: "Node.js", level: 80 },
                  { name: "AWS", level: 75 }
                ].map((skill, index) => (
                  <div key={index} className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-1000 ease-out skill-bar"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-6">Sosyal Yetenekler</h3>
                {[
                  { name: "Takım Çalışması", level: 95 },
                  { name: "Liderlik", level: 85 },
                  { name: "İletişim", level: 90 },
                  { name: "Problem Çözme", level: 88 }
                ].map((skill, index) => (
                  <div key={index} className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium text-gray-700">{skill.name}</span>
                      <span className="text-sm text-gray-500">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full transition-all duration-1000 ease-out skill-bar"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* İlgi Alanları Section */}
        <section id="ilgi-alanlari" className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">İlgi Alanları</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                { name: "Fotoğrafçılık", icon: "📸" },
                { name: "Seyahat", icon: "✈️" },
                { name: "Kitap Okuma", icon: "📚" },
                { name: "Müzik", icon: "🎵" },
                { name: "Spor", icon: "⚽" },
                { name: "Teknoloji", icon: "💻" },
                { name: "Sanat", icon: "🎨" },
                { name: "Doğa", icon: "🌲" }
              ].map((interest, index) => (
                <Card key={index} className="text-center hover:shadow-lg transition-shadow duration-300 cursor-pointer card-hover hover-scale">
                  <CardContent className="pt-6">
                    <div className="text-4xl mb-4 animate-float">{interest.icon}</div>
                    <h3 className="font-semibold text-gray-900">{interest.name}</h3>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* İletişim Section */}
        <section id="iletisim" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">İletişim</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold mb-6">İletişim Bilgileri</h3>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Mail className="text-blue-600" size={20} />
                    <span>ornek@email.com</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="text-blue-600" size={20} />
                    <span>+90 555 123 45 67</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="text-blue-600" size={20} />
                    <span>İstanbul, Türkiye</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-semibold mb-6">Mesaj Gönder</h3>
                <form className="space-y-4">
                  <div>
                    <Label htmlFor="name">Ad Soyad</Label>
                    <Input id="name" placeholder="Adınızı girin" />
                  </div>
                  <div>
                    <Label htmlFor="email">E-posta</Label>
                    <Input id="email" type="email" placeholder="E-posta adresinizi girin" />
                  </div>
                  <div>
                    <Label htmlFor="message">Mesaj</Label>
                    <Textarea id="message" placeholder="Mesajınızı yazın" rows={4} />
                  </div>
                  <Button type="submit" className="w-full">
                    <Send size={16} className="mr-2" />
                    Gönder
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Danışmanlık Section */}
        <section id="danismanlik" className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Danışmanlık</h2>
            <Card className="max-w-2xl mx-auto">
              <CardHeader>
                <CardTitle>Danışmanlık Talebi</CardTitle>
                <CardDescription>
                  Projeleriniz için profesyonel danışmanlık hizmeti almak istiyorsanız, 
                  aşağıdaki formu doldurarak bizimle iletişime geçebilirsiniz.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div>
                    <Label htmlFor="consultant-name">Ad Soyad</Label>
                    <Input id="consultant-name" placeholder="Adınızı girin" />
                  </div>
                  <div>
                    <Label htmlFor="consultant-email">E-posta</Label>
                    <Input id="consultant-email" type="email" placeholder="E-posta adresinizi girin" />
                  </div>
                  <div>
                    <Label htmlFor="consultant-phone">Telefon</Label>
                    <Input id="consultant-phone" placeholder="Telefon numaranızı girin" />
                  </div>
                  <div>
                    <Label htmlFor="consultant-topic">Danışmak İstediğiniz Konu</Label>
                    <Textarea 
                      id="consultant-topic" 
                      placeholder="Hangi konuda danışmanlık almak istiyorsunuz? Detayları belirtin..." 
                      rows={5} 
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    <Send size={16} className="mr-2" />
                    Danışmanlık Talebi Gönder
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      {/* Chatbot */}
      <div className="fixed bottom-6 right-6 z-50">
        {isChatbotOpen && (
          <Card className="w-80 h-96 mb-4 shadow-xl">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-center">
                <CardTitle className="text-lg">Yardımcı</CardTitle>
                <button
                  onClick={() => setIsChatbotOpen(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={20} />
                </button>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col h-full">
              <div className="flex-1 overflow-y-auto mb-4 space-y-2">
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`p-2 rounded-lg text-sm chat-message ${
                      msg.type === 'bot'
                        ? 'bg-gray-100 text-gray-800'
                        : 'bg-blue-500 text-white ml-8'
                    }`}
                  >
                    {msg.message}
                  </div>
                ))}
              </div>
              <form onSubmit={handleChatSubmit} className="flex gap-2">
                <Input
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Mesajınızı yazın..."
                  className="flex-1"
                />
                <Button type="submit" size="sm">
                  <Send size={16} />
                </Button>
              </form>
            </CardContent>
          </Card>
        )}
        <Button
          onClick={() => setIsChatbotOpen(!isChatbotOpen)}
          className="rounded-full w-14 h-14 shadow-lg"
        >
          <MessageCircle size={24} />
        </Button>
      </div>
    </div>
  )
}

export default App

